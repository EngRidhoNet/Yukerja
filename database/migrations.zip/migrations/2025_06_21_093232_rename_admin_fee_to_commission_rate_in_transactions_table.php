<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

class RenameAdminFeeToCommissionRateInTransactionsTable extends Migration
{
    public function up()
    {
        DB::statement(<<<'SQL'
            ALTER TABLE `transactions`
            CHANGE COLUMN `admin_fee` `commission_rate` DECIMAL(5,2) NOT NULL DEFAULT '20.00'
        SQL
        );
    }

    public function down()
    {
        DB::statement(<<<'SQL'
            ALTER TABLE `transactions`
            CHANGE COLUMN `commission_rate` `admin_fee` DECIMAL(12,2) NOT NULL
        SQL
        );
    }
}
