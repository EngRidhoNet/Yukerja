<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRevenueTable extends Migration
{
    public function up()
    {
        Schema::create('revenue', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('key', 100)->unique()->comment('Nama setting, misal commission_rate');
            $table->decimal('value', 5, 2)->comment('Persentase komisi, misal 20.00');
            $table->unsignedBigInteger('updated_by')->nullable()->comment('User admin yang terakhir mengubah');
            $table->unsignedBigInteger('transaction_id')->nullable()->comment('FK ke transactions.id');
            $table->decimal('amount', 14, 2)->nullable()->comment('Nilai transaksi, diambil dari transactions.amount');
            $table->decimal('revenue', 14, 2)->nullable()->comment('Perhitungan: amount * (value / 100)');
            $table->timestamps();

            $table->foreign('updated_by')->references('id')->on('users')->onDelete('set null');
            $table->foreign('transaction_id')->references('id')->on('transactions')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::dropIfExists('revenue');
    }
}
