<?php

namespace App\Filament\Resources\ChatifyRedirectResource\Pages;

use App\Filament\Resources\ChatifyRedirectResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateChatifyRedirect extends CreateRecord
{
    protected static string $resource = ChatifyRedirectResource::class;
}
